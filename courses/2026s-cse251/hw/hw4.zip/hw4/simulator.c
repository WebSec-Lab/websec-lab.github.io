#include "hw4_lib.h"

int main() {
    printSummary(0, 0, 0);
    return 0;
}
