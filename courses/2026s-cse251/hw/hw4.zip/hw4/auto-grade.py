#!/usr//bin/python2
#
# driver.py - The driver tests the correctness of the student's cache
#     simulator and the correctness and performance of their transpose
#     function. It uses ./eval-simulator to check the correctness of the
#     simulator and it runs ./eval-transpose on three different sized
#     matrices (32x32, 64x64, and 61x67) to test the correctness and
#     performance of the transpose function.
#
import subprocess;
import re;
import os;
import sys;
import optparse;

#
# computeMissScore - compute the score depending on the number of
# cache misses
# trans32_score = computeMissScore(miss32, 300, 600, maxscore['trans32']) * int(result32[0])
#
def computeMissScore(miss, lower, upper, full_score):
    if miss <= lower:
        return full_score
    if miss >= upper:
        return 0

    score = (miss - lower) * 1.0
    range = (upper- lower) * 1.0
    return round((1 - score / range) * full_score, 1)

#
# main - Main function
#
def main():

    # Configure maxscores here
    maxscore= {};
    maxscore['simulator'] = 66
    maxscore['transc'] = 5
    maxscore['trans32'] = 19
    maxscore['trans64'] = 19
    maxscore['trans61'] = 23

    # Parse the command line arguments

    # Check the correctness of the cache simulator
    print "Part A: Testing cache simulator"
    print "Running ./eval-simulator"
    p = subprocess.Popen("./eval-simulator",
                         shell=True, stdout=subprocess.PIPE)
    stdout_data = p.communicate()[0]

    # Emit the output from eval-simulator
    stdout_data = re.split('\n', stdout_data)
    for line in stdout_data:
        if re.match("TEST_SIM_RESULTS", line):
            resultsim = re.findall(r'(\d+)', line)
            if "LRU" in line:
                resultsimlru = resultsim
            else:
                resultsimlfu = resultsim
        else:
            print "%s" % (line)

    # Check the correctness and performance of the transpose function
    # 32x32 transpose
    print "Part B: Testing transpose function"
    print "Running ./eval-transpose -M 32 -N 32"
    p = subprocess.Popen("./eval-transpose -M 32 -N 32 | grep TEST_TRANS_RESULTS",
                         shell=True, stdout=subprocess.PIPE)
    stdout_data = p.communicate()[0]
    result32 = re.findall(r'(\d+)', stdout_data)

    # 64x64 transpose
    print "Running ./eval-transpose -M 64 -N 64"
    p = subprocess.Popen("./eval-transpose -M 64 -N 64 | grep TEST_TRANS_RESULTS",
                         shell=True, stdout=subprocess.PIPE)
    stdout_data = p.communicate()[0]
    result64 = re.findall(r'(\d+)', stdout_data)

    # 61x67 transpose
    print "Running ./eval-transpose -M 61 -N 67"
    p = subprocess.Popen("./eval-transpose -M 61 -N 67 | grep TEST_TRANS_RESULTS",
                         shell=True, stdout=subprocess.PIPE)
    stdout_data = p.communicate()[0]
    result61 = re.findall(r'(\d+)', stdout_data)

    # Compute the scores for each step
    simulator_cscore_lru  = map(int, resultsimlru[0:1])
    simulator_cscore_lfu  = map(int, resultsimlfu[0:1])
    trans_cscore = int(result32[0]) * int(result64[0]) * int(result61[0]);
    miss32 = int(result32[1])
    miss64 = int(result64[1])
    miss61 = int(result61[1])
    trans32_score = computeMissScore(miss32, 300, 600, maxscore['trans32']) * int(result32[0])
    trans64_score = computeMissScore(miss64, 1300, 2000, maxscore['trans64']) * int(result64[0])
    trans61_score = computeMissScore(miss61, 2000, 3000, maxscore['trans61']) * int(result61[0])
    total_score = simulator_cscore_lru[0] + simulator_cscore_lfu[0] + trans32_score + trans64_score + trans61_score


    # Summarize the results
    print "\nHW4 grading summary:"
    print "%-22s%8s%10s%12s" % ("", "Points", "Max pts", "Misses")
    print "%-22s%8.1f%10d" % ("Simualtor correctness", simulator_cscore_lru[0] + simulator_cscore_lfu[0],
                              maxscore['simulator'])

    misses = str(miss32)
    if miss32 == 2**31-1 :
        misses = "invalid"
    print "%-22s%8.1f%10d%12s" % ("Transpose perf 32x32", trans32_score,
                                  maxscore['trans32'], misses)

    misses = str(miss64)
    if miss64 == 2**31-1 :
        misses = "invalid"
    print "%-22s%8.1f%10d%12s" % ("Transpose perf 64x64", trans64_score,
                                  maxscore['trans64'], misses)

    misses = str(miss61)
    if miss61 == 2**31-1 :
        misses = "invalid"
    print "%-22s%8.1f%10d%12s" % ("Transpose perf 61x67", trans61_score,
                                  maxscore['trans61'], misses)

    print "%22s%8.1f%10d" % ("Total points", total_score,
                             maxscore['simulator'] +
                             maxscore['trans32'] +
                             maxscore['trans64'] +
                             maxscore['trans61'])



# execute main only if called as a script
if __name__ == "__main__":
    main()

